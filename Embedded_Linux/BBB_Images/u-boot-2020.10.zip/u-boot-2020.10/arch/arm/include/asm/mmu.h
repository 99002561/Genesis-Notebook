/* SPDX-License-Identifier: GPL-2.0+ */

#ifndef __ASM_ARM_MMU_H
#define __ASM_ARM_MMU_H

void init_addr_map(void);

#endif
