/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2004, 2007-2010, 2011-2015 Synopsys, Inc. All rights reserved.
 */

#ifndef __ASM_ARC_LINKAGE_H
#define __ASM_ARC_LINKAGE_H

#define ASM_NL		 `	/* use '`' to mark new line in macro */

#endif /* __ASM_ARC_LINKAGE_H */
