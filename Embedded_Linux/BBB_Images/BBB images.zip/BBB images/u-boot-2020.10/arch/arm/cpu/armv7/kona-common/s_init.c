// SPDX-License-Identifier: GPL-2.0+
/*
 * Copyright 2014 Broadcom Corporation.
 */

/*
 * Early system init. Currently empty.
 */
void s_init(void)
{
}
