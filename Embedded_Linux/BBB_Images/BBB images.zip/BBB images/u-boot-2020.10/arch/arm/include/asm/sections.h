/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (c) 2012 The Chromium OS Authors.
 */

#ifndef __ASM_ARM_SECTIONS_H
#define __ASM_ARM_SECTIONS_H

#include <asm-generic/sections.h>

#endif
