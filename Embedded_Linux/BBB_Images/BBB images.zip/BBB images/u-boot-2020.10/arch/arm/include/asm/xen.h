/* SPDX-License-Identifier: GPL-2.0+
 *
 * (C) 2020 EPAM Systems Inc.
 */

extern unsigned long rom_pointer[];

